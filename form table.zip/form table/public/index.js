let productList = [];
let orderCount = 0;

window.onload = async () => {
  await fetchProducts();
  addNewRow();
};

async function fetchProducts() {
  const res = await fetch('/api/products');
  productList = await res.json();
}

function addNewRow() {
  const tbody = document.getElementById("orderBody");

  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = String(now.getMonth() + 1).padStart(2, '0');
  orderCount += 1;
  const orderNumber = `${day}-${month}-${String(orderCount).padStart(3, '0')}`;

  const row = document.createElement("tr");

  row.innerHTML = `
    <td><input value="${orderNumber}" disabled></td>
    <td><input></td>
    <td><input placeholder="MM/DD/YYYY"></td>
    <td><input placeholder="MM/DD/YYYY"></td>
    <td><input></td>
    <td><input list="products" oninput="filterProducts(this)" autocomplete="off"></td>
    <td><input type="number" step="0.01" oninput="calculateTotal(this)"></td>
    <td><input type="number" step="1" oninput="calculateTotal(this)"></td>
    <td><input disabled></td>
    <td>
      <button onclick="saveRow(this)">Save</button>
      <button onclick="cancelRow(this)">Cancel</button>
    </td>
  `;

  tbody.appendChild(row);
}

function filterProducts(input) {
  const list = document.getElementById("products");
  list.innerHTML = '';
  const val = input.value.toLowerCase();
  productList.filter(p => p.ITEM_CODE.toLowerCase().includes(val))
    .forEach(p => {
      const option = document.createElement("option");
      option.value = p.ITEM_CODE;
      list.appendChild(option);
    });
}

function calculateTotal(input) {
  const row = input.closest("tr");
  const unitPrice = parseFloat(row.children[6].querySelector("input").value) || 0;
  const qty = parseInt(row.children[7].querySelector("input").value) || 0;
  row.children[8].querySelector("input").value = (unitPrice * qty).toFixed(2);
}

async function saveRow(btn) {
  const row = btn.closest("tr");
  const cells = row.querySelectorAll("input");
  const order = {
    orderNumber: cells[0].value,
    customer: cells[1].value,
    orderDate: cells[2].value,
    requiredDate: cells[3].value,
    shipToAddress: cells[4].value,
    product: cells[5].value,
    unitPrice: parseFloat(cells[6].value),
    quantity: parseInt(cells[7].value),
    total: parseFloat(cells[8].value),
  };

  const res = await fetch('/api/orders', {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(order)
  });

  const data = await res.json();
  if (data.success) {
    btn.disabled = true;
    row.querySelectorAll("input").forEach(inp => inp.disabled = true);
    addNewRow();
  } else {
    alert("Save failed");
  }
}

function cancelRow(btn) {
  const row = btn.closest("tr");
  row.remove();
}

