const express = require('express');
const sql = require('mssql');
const path = require('path');
const app = express();
const PORT = 5000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const config = {
  user: "sa",
  password: "root",
  server: "127.0.0.1",
  database: "TRYME",
  options: {
    encrypt: true,
    trustServerCertificate: true
  }
};

const pool = new sql.ConnectionPool(config);
const poolConnect = pool.connect();

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/api/products', async (req, res) => {
  await poolConnect;
  const result = await pool.request().query('SELECT ITEM_CODE FROM INV_BIN_TRN');
  res.json(result.recordset);
});

app.post('/api/orders', async (req, res) => {
  await poolConnect;
  const {
    orderNumber, customer, orderDate, requiredDate,
    shipToAddress, product, unitPrice, quantity, total
  } = req.body;

  try {
    await pool.request()
      .input('orderNumber', sql.VarChar, orderNumber)
      .input('customer', sql.VarChar, customer)
      .input('orderDate', sql.Date, orderDate)
      .input('requiredDate', sql.Date, requiredDate)
      .input('shipToAddress', sql.VarChar, shipToAddress)
      .input('product', sql.VarChar, product)
      .input('unitPrice', sql.Decimal(10, 2), unitPrice)
      .input('quantity', sql.Int, quantity)
      .input('total', sql.Decimal(10, 2), total)
      .query(`INSERT INTO Orders 
              (orderNumber, customer, orderDate, requiredDate, shipToAddress, product, unitPrice, quantity, total)
              VALUES (@orderNumber, @customer, @orderDate, @requiredDate, @shipToAddress, @product, @unitPrice, @quantity, @total)`);

    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
