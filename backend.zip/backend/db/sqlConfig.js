const sql = require('mssql');

const config = {
  user: "sa",
  password: "root",
  server: "127.0.0.1",
  database: "TRYME",
  options: {
    encrypt: true,
    trustServerCertificate: true
  }
};

const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then(pool => {
    console.log('Connected to MSSQL');
    return pool;
  })
  .catch(err => console.error('DB Connection Failed:', err));

module.exports = { sql, poolPromise };
