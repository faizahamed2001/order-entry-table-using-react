const express = require('express');
const cors = require('cors');
const app = express();
const orderRoutes = require('./routes/orders');
const productRoutes = require('./routes/products');

app.use(cors());
app.use(express.json());

app.use('/api/orders', orderRoutes);
app.use('/api/products', productRoutes);

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
