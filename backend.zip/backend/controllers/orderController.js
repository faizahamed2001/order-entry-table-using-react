const { poolPromise, sql } = require('../db/sqlConfig');

const saveOrder = async (req, res) => {
  try {
    const {
      orderNumber, customer, orderDate, requiredDate,
      shipToAddress, product, unitPrice, quantity, total
    } = req.body;

    const pool = await poolPromise;
    await pool.request()
      .input('orderNumber', sql.VarChar, orderNumber)
      .input('customer', sql.VarChar, customer)
      .input('orderDate', sql.Date, orderDate)
      .input('requiredDate', sql.Date, requiredDate)
      .input('shipToAddress', sql.VarChar, shipToAddress)
      .input('product', sql.VarChar, product)
      .input('unitPrice', sql.Decimal(10, 2), unitPrice)
      .input('quantity', sql.Int, quantity)
      .input('total', sql.Decimal(10, 2), total)
      .query(`
        INSERT INTO Orders (orderNumber, customer, orderDate, requiredDate, shipToAddress, product, unitPrice, quantity, total)
        VALUES (@orderNumber, @customer, @orderDate, @requiredDate, @shipToAddress, @product, @unitPrice, @quantity, @total)
      `);

    res.json({
      success: true,
      order: req.body
    });
  } catch (err) {
    console.error('Error saving order:', err);
    res.status(500).json({ success: false, message: 'Failed to save order' });
  }
};

const getOrders = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query(`SELECT * FROM Orders ORDER BY orderNumber`);
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
};

module.exports = { saveOrder, getOrders };
