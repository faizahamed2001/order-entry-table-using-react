const { poolPromise } = require('../db/sqlConfig');

const getProducts = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query(`SELECT ITEM_CODE FROM INT_BIN_TRN`);
    res.json(result.recordset);
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
};

module.exports = { getProducts };
